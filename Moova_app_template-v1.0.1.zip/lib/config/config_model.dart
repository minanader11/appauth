enum Environment {
  dev,
  lab,
  prod,
}

class ConfigModel {


  String serverApiUrl = "";
  String serverPortalUrl = "";

  int versionNumber = 1;

  String baseUrlTicketing = "";

  String identityServerDomain = "";
  String authDomain = "";
  String authClientId = "";
  String discoveryUrl = "";
  String redirectUrl = "";
  String fixedToken = "";

  late Environment enviroment;

  ConfigModel();
}
