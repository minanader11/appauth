import 'package:enum_to_string/enum_to_string.dart';

import 'config_model.dart';

class ConfigBuilder {
  ///
  static ConfigModel buildConfig() {
    const environment = String.fromEnvironment("environment");

    ConfigModel configModel = ConfigModel();

    switch (EnumToString.fromString(Environment.values, environment)) {
      case Environment.dev:
      case null:
        // ------------------------------------------------------------
        //  1) ++++++++ DEV
        // ------------------------------------------------------------
        configModel
          ..enviroment = Environment.dev

          // ------------------------------------------------------------
          //  1) BASE URL DEV
          // ------------------------------------------------------------
          ..serverApiUrl = "https://example.com"
          ..baseUrlTicketing = "/path/example/products"

          // ------------------------------------------------------------
          //  2) WSO2 DEV1h
          // ------------------------------------------------------------
          ..identityServerDomain = "com.example.is"
          ..redirectUrl = "com.example.cairo.cairo://callback"
          ..authClientId =
              "XXXXX"
          ..discoveryUrl =
              "https://${configModel.identityServerDomain}/oauth2/token/.well-known/openid-configuration";

        break;
      case Environment.lab:
        break;
      case Environment.prod:
        break;
    }

    return configModel;
  }
}
