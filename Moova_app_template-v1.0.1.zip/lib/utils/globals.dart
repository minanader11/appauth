library globals;

import '../model/user/user_info_oauth.dart';

//replace global variable with save in storage
UserInfoOauth user = UserInfoOauth(userName: '',accessToken:  '', refreshToken: '');