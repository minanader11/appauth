class Images {
  static const String bus = 'assets/images/bus.jpg';
}
