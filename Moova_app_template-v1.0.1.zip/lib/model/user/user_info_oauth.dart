class UserInfoOauth {

  String    userName;
  String    refreshToken;
  String    accessToken;



  UserInfoOauth({
    required this.userName,
    required this.refreshToken,
    required this.accessToken,
  });
}