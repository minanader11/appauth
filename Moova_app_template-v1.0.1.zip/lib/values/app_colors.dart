import 'package:flutter/material.dart';

class AppColors {
  static Color primaryColor = const Color(0xff5fbebe);
  static Color buttonColor = const Color(0xffC32F26);
  static Color appBarColor = const Color(0xff1B477C);
  static const grey = Color(0xffc0c0c0);
}
