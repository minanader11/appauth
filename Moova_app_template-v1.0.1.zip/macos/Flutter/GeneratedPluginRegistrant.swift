//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_appauth

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FlutterAppauthPlugin.register(with: registry.registrar(forPlugin: "FlutterAppauthPlugin"))
}
