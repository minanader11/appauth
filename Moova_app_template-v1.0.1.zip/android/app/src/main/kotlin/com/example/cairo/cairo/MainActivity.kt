package com.example.cairo.cairo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
